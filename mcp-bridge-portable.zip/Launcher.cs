using System;
using System.Diagnostics;
using System.IO;
using System.Threading;

class Launcher {
    static void Main(string[] args) {
        try {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.InputEncoding = System.Text.Encoding.UTF8;
        } catch {}

        Console.Title = "MCP Control Center & Universal API Bridge";
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("====================================================");
        Console.WriteLine("   🚀 MCP Control Center & Universal API Bridge     ");
        Console.WriteLine("====================================================");
        Console.ResetColor();

        string appDir = AppDomain.CurrentDomain.BaseDirectory;
        string rootDir = Path.GetFullPath(Path.Combine(appDir, ".."));
        
        // Find dist/app.js (check local directory first for portable standalone mode)
        string targetScript = Path.Combine(appDir, "dist", "app.js");
        string workingDir = appDir;

        if (!File.Exists(targetScript)) {
            targetScript = Path.Combine(rootDir, "dist", "app.js");
            workingDir = rootDir;
        }

        if (!File.Exists(targetScript)) {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("[Launcher] ❌ Cannot find dist/app.js at: " + targetScript);
            Console.WriteLine("Please make sure you have run 'npm run build' first.");
            Console.ResetColor();
            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();
            return;
        }

        Console.WriteLine("[Launcher] Working Directory: " + workingDir);
        Console.WriteLine("[Launcher] Target Script:    " + targetScript);

        // Find node executable
        string nodeExe = "node";
        string defaultNode = @"C:\Program Files\nodejs\node.exe";
        if (File.Exists(defaultNode)) {
            nodeExe = defaultNode;
        }

        ProcessStartInfo psi = new ProcessStartInfo {
            FileName = nodeExe,
            Arguments = "\"" + targetScript + "\"",
            WorkingDirectory = workingDir,
            UseShellExecute = false
        };

        psi.EnvironmentVariables["AUTO_OPEN_BROWSER"] = "false";

        try {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\n[Launcher] ⚡ Starting MCP Bridge Engine...");
            Console.ResetColor();

            Process proc = Process.Start(psi);
            if (proc == null) {
                throw new Exception("Failed to start node process.");
            }

            // Launch browser to control center after delay
            new Thread(() => {
                Thread.Sleep(1500);
                try {
                    Process.Start(new ProcessStartInfo("cmd", "/c start http://localhost:3000/") { CreateNoWindow = true });
                } catch {}
            }).Start();

            Console.WriteLine("[Launcher] 🟢 Server running! Press Ctrl+C or use the 'Shut Down' button on web to stop.");
            proc.WaitForExit();
            if (proc.ExitCode != 0) {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\n[Launcher] ⚠️ Process exited with error code: " + proc.ExitCode);
                Console.ResetColor();
                Console.WriteLine("\nPress any key to exit...");
                try { Console.ReadKey(); } catch {}
            }
            Environment.Exit(proc.ExitCode);
        } catch (Exception ex) {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\n[Launcher] ❌ Error: " + ex.Message);
            Console.ResetColor();
            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();
        }
    }
}
