# 🚀 MCP Bridge Control Center (Standalone Program)

โปรแกรมรันตัวกลางเชื่อมต่อ **Model Context Protocol (MCP)** สำหรับ Windows ที่สามารถเปิดใช้งานได้ทันทีในคลิกเดียว พร้อมหน้าต่างควบคุม **Control Center Dashboard** บนเว็บบราวเซอร์

---

## 📁 ไฟล์ภายในโฟลเดอร์นี้

* **`mcp-bridge.exe`** : ไฟล์โปรแกรม Windows Executable ดับเบิ้ลคลิกเพื่อเริ่มทำงานได้ทันที
* **`start.bat`** : สคริปต์ทางเลือกสำหรับคนที่ชอบเปิดผ่าน Batch file
* **`config.json`** : ไฟล์บันทึกการตั้งค่า (Path MCP, API Key, พอร์ต, Tunnel URL)
* **`Launcher.cs`** : ซอร์สโค้ดภาษา C# ของตัวรัน (สำหรับ Recompile ได้ในอนาคต)

---

## 🚦 วิธีเปิดใช้งาน

1. ดับเบิ้ลคลิกที่ไฟล์ **`mcp-bridge.exe`** (หรือ `start.bat`)
2. ตัวโปรแกรมจะเริ่มทำงาน และเปิดหน้าต่างเว็บบราวเซอร์ **Control Center** ไปที่:  
   👉 **`http://localhost:3000/`** ให้อัตโนมัติทันที!

---

## 🌟 ฟังก์ชันหลักบนหน้าต่าง Control Center

### 1. แท็บ 🎮 Tool Explorer
* ดูรายชื่อ Tools ทั้งหมด (เช่น 68 Tools ของ Roblox `real-mcp.exe`)
* ดูคำอธิบาย และ Input Schema
* ทดสอบยิงคำสั่ง (`ping`, `list-clients`, ฯลฯ) พร้อมดู Response แบบ Real-time

### 2. แท็บ ⚙️ MCP Target & Key (ตั้งค่าตามความต้องการ)
* **เปลี่ยน Path MCP ปลายทาง:** สามารถพิมพ์เปลี่ยน Path ของไฟล์ `.exe` หรือสคริปต์ตัวอื่นในเครื่องได้ตลอดเวลา มีปุ่มกด *Verify Path* และปุ่มรีเซ็ตเป็น *real-mcp.exe*
* **สุ่มสร้าง API Key ใหม่:** มีปุ่ม **"🎲 Generate Random Key"** ให้สุ่มรหัสผ่าน 32 ตัวอักษรใหม่ได้ในคลิกเดียว พร้อมปุ่ม Copy
* **บันทึกทันที:** กดปุ่ม **"💾 Save Settings & Reconnect MCP"** ระบบจะบันทึกลง `config.json` และเชื่อมต่อกับ MCP ตัวใหม่ให้ทันทีโดยไม่ต้องปิดโปรแกรม!

### 3. แท็บ 🌐 AI Connectors (ngrok)
* **กรอกตั้งค่าแบบ Manual เท่านั้น (ไม่ตรวจจับอัตโนมัติ):** สามารถคัดลอกคำสั่งเริ่มต้นจาก ngrok มาวางได้โดยตรง เช่น:
  `ngrok http 80 --url https://drudge-cofounder-crafter.ngrok-free.dev`
* **แปลงพอร์ต 80 เป็น 3000 ให้อัตโนมัติ:** ระบบจะตรวจจับ Subdomain ที่เปลี่ยนไปเรื่อยๆ ตามแพ็กเกจฟรีของ ngrok และสร้างคำสั่งสำหรับรันใน Terminal ที่แก้ไขพอร์ตเป็น `3000` ให้ทันที พร้อมปุ่ม `📋 คัดลอกคำสั่งไปรัน`
* **อัปเดตลิงก์ AI ทันที (1-Click Copy):**
  * **Google Gemini Spark:** `https://<your-subdomain>.ngrok-free.dev/mcp` (Streamable HTTP)
  * **Anthropic Claude:** `https://<your-subdomain>.ngrok-free.dev/mcp` (Streamable HTTP / No sign-in)
  * **Desktop Plugins (Cursor/Raycast):** `https://<your-subdomain>.ngrok-free.dev/sse` (SSE)
  * **REST Webhook (LINE/Telegram):** `POST https://<your-subdomain>.ngrok-free.dev/execute-tool`

