#!/usr/bin/env node
/**
 * local-mcp  —  MCP server (stdio) ที่ให้ AI ทำงานกับไฟล์ในเครื่อง
 *
 * ใช้งานร่วมกับ mcp-bridge: ตั้ง MCP_STDIO_COMMAND = "node"
 *   MCP_STDIO_ARGS = ["C:\\path\\to\\local-mcp.mjs", "--root", "D:\\AI-Workspace"]
 *
 * ตัวเลือก:
 *   --root <dir>            โฟลเดอร์ทำงาน (AI เข้าถึงได้เฉพาะในนี้)  [default: ./workspace]
 *   --readonly              ปิดทุก tool ที่เขียน/ลบ/รันคำสั่ง
 *   --allow-shell a,b,c     เปิด run_command เฉพาะคำสั่งในรายการ เช่น npm,node,git,python
 *
 * หมายเหตุ: stdout ใช้สำหรับโปรโตคอล MCP เท่านั้น ห้าม console.log — log ออก stderr
 */
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { z } from 'zod';
import fs from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

// ---------- config จาก argv ----------
function parseArgs(argv) {
  const o = { root: null, readonly: false, shell: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--root') o.root = argv[++i];
    else if (a === '--readonly') o.readonly = true;
    else if (a === '--allow-shell') o.shell = (argv[++i] || '').split(',').map((s) => s.trim().toLowerCase()).filter(Boolean);
  }
  return o;
}
const opts = parseArgs(process.argv.slice(2));
const here = path.dirname(fileURLToPath(import.meta.url));
const ROOT_INPUT = path.resolve(opts.root || path.join(here, 'workspace'));
await fs.mkdir(ROOT_INPUT, { recursive: true });
const ROOT = await fs.realpath(ROOT_INPUT);

const MAX_READ_BYTES = 1_000_000; // 1 MB ต่อการอ่าน
const MAX_OUTPUT_CHARS = 60_000;
const SKIP_DIRS = new Set(['node_modules', '.git', '__pycache__']);
// ไฟล์ลับที่ไม่ให้แตะ แม้จะอยู่ในโฟลเดอร์ทำงาน
const SECRET_RE = /(^|[\\/])(\.env(\..*)?|\.ssh|id_rsa|id_ed25519|.*\.pem|.*\.pfx|\.npmrc|\.aws|credentials(\.json)?)$/i;

const log = (...a) => console.error('[local-mcp]', ...a);

// ---------- path safety ----------
async function resolveSafe(rel, { mustExist = false } = {}) {
  const input = rel === undefined || rel === '' ? '.' : String(rel);
  if (input.includes('\0')) throw new Error('path ไม่ถูกต้อง');
  const abs = path.resolve(ROOT, input);
  const within = (p) => {
    const r = path.relative(ROOT, p);
    return r === '' || (!r.startsWith('..') && !path.isAbsolute(r));
  };
  if (!within(abs)) throw new Error(`ปฏิเสธ: path อยู่นอกโฟลเดอร์ทำงาน (${ROOT})`);
  if (SECRET_RE.test(abs)) throw new Error('ปฏิเสธ: ไฟล์นี้อยู่ในรายการไฟล์ลับ');
  // กัน symlink/junction ที่ชี้ออกนอก root: realpath ของ ancestor ที่มีอยู่จริงต้องยังอยู่ใน root
  let probe = abs;
  for (;;) {
    try {
      const real = await fs.realpath(probe);
      if (!within(real)) throw new Error('ปฏิเสธ: ลิงก์ชี้ออกนอกโฟลเดอร์ทำงาน');
      break;
    } catch (e) {
      if (e.code === 'ENOENT') {
        const parent = path.dirname(probe);
        if (parent === probe) break;
        probe = parent;
      } else throw e;
    }
  }
  if (mustExist) await fs.stat(abs); // โยน ENOENT ถ้าไม่มี
  return abs;
}
const rel = (abs) => path.relative(ROOT, abs).split(path.sep).join('/') || '.';

const text = (t) => ({ content: [{ type: 'text', text: t }] });
const fail = (e) => ({ isError: true, content: [{ type: 'text', text: `Error: ${e?.message || e}` }] });
const guard = (fn) => async (args) => {
  try { return await fn(args); } catch (e) { return fail(e); }
};
const clip = (s) => (s.length > MAX_OUTPUT_CHARS ? s.slice(0, MAX_OUTPUT_CHARS) + `\n…[ตัดทิ้ง ${s.length - MAX_OUTPUT_CHARS} ตัวอักษร]` : s);

// ---------- server ----------
const server = new McpServer({ name: 'local-workspace', version: '1.0.0' });

const workspaceOverviewHandler = guard(async () => text(JSON.stringify({
  root: ROOT, platform: process.platform, readonly: opts.readonly,
  shellAllowed: opts.readonly ? [] : opts.shell,
  commandTool: opts.readonly || !opts.shell.length ? 'disabled' : 'run_command or execute_command (use this to execute terminal/shell commands)',
  maxReadBytes: MAX_READ_BYTES,
}, null, 2)));

server.registerTool('workspace_overview', {
  description: 'Inspect workspace root summary, access permissions, and allowed terminal commands (call to check environment before starting work)',
  inputSchema: {},
}, workspaceOverviewHandler);

server.registerTool('workspace_info', {
  description: 'Inspect workspace root summary, access permissions, and allowed terminal commands (alias of workspace_overview)',
  inputSchema: {},
}, workspaceOverviewHandler);

server.registerTool('list_directory', {
  description: 'List files and directories (path relative to workspace root) with recursive depth support',
  inputSchema: {
    path: z.string().default('.').describe('Target folder path (e.g. "." or "my-app/src")'),
    depth: z.number().int().min(1).max(6).default(1).describe('Traversal depth (1 = single level)'),
  },
}, guard(async ({ path: p, depth }) => {
  const start = await resolveSafe(p, { mustExist: true });
  const lines = [];
  async function walk(dir, d) {
    const entries = (await fs.readdir(dir, { withFileTypes: true })).sort((a, b) => a.name.localeCompare(b.name));
    for (const e of entries) {
      if (lines.length >= 2000) return;
      const full = path.join(dir, e.name);
      if (SECRET_RE.test(full)) continue;
      if (e.isDirectory()) {
        lines.push(rel(full) + '/');
        if (d < depth && !SKIP_DIRS.has(e.name)) await walk(full, d + 1);
      } else {
        const st = await fs.stat(full).catch(() => null);
        lines.push(`${rel(full)}  (${st ? st.size : '?'} B)`);
      }
    }
  }
  await walk(start, 1);
  return text(lines.length ? lines.join('\n') : '(ว่าง)');
}));

server.registerTool('read_file', {
  description: 'Read UTF-8 text file with line offset and limit pagination for large files',
  inputSchema: {
    path: z.string().describe('Relative path to file'),
    offset: z.number().int().min(1).default(1).describe('Starting line number (1-based)'),
    limit: z.number().int().min(1).max(5000).default(2000).describe('Maximum number of lines to read'),
  },
}, guard(async ({ path: p, offset, limit }) => {
  const abs = await resolveSafe(p, { mustExist: true });
  const st = await fs.stat(abs);
  if (!st.isFile()) throw new Error('ไม่ใช่ไฟล์');
  if (st.size > MAX_READ_BYTES * 5) throw new Error(`ไฟล์ใหญ่เกินไป (${st.size} B)`);
  const buf = await fs.readFile(abs);
  if (buf.subarray(0, 8000).includes(0)) throw new Error('ดูเหมือนเป็นไฟล์ไบนารี อ่านเป็นข้อความไม่ได้');
  const all = buf.toString('utf8').split('\n');
  const slice = all.slice(offset - 1, offset - 1 + limit);
  const out = slice.join('\n');
  const more = offset - 1 + limit < all.length ? `\n…[ยังมีต่อ: ทั้งหมด ${all.length} บรรทัด, ใช้ offset=${offset + limit}]` : '';
  return text(clip(out) + more);
}));

if (!opts.readonly) {
  server.registerTool('write_file', {
    description: 'Write content to file (creates parent directories automatically). Refuses overwrite by default unless overwrite=true',
    inputSchema: {
      path: z.string().describe('Relative path to file'),
      content: z.string().describe('Text content to write'),
      overwrite: z.boolean().default(false).describe('Allow overwriting existing file if true'),
    },
  }, guard(async ({ path: p, content, overwrite }) => {
    const abs = await resolveSafe(p);
    if (abs === ROOT) throw new Error('path ไม่ถูกต้อง');
    await fs.mkdir(path.dirname(abs), { recursive: true });
    await fs.writeFile(abs, content, { encoding: 'utf8', flag: overwrite ? 'w' : 'wx' }).catch((e) => {
      if (e.code === 'EEXIST') throw new Error('ไฟล์นี้มีอยู่แล้ว (ตั้ง overwrite=true ถ้าต้องการทับ)');
      throw e;
    });
    log('write', rel(abs));
    return text(`เขียน ${rel(abs)} แล้ว (${Buffer.byteLength(content)} B)`);
  }));

  server.registerTool('edit_file', {
    description: 'Edit file by replacing exact old_text with new_text (old_text must match exactly once in file)',
    inputSchema: {
      path: z.string().describe('Relative path to file'),
      old_text: z.string().min(1).describe('Exact existing text snippet to replace'),
      new_text: z.string().describe('New replacement text'),
    },
  }, guard(async ({ path: p, old_text, new_text }) => {
    const abs = await resolveSafe(p, { mustExist: true });
    const src = await fs.readFile(abs, 'utf8');
    const n = src.split(old_text).length - 1;
    if (n === 0) throw new Error('ไม่พบ old_text ในไฟล์');
    if (n > 1) throw new Error(`old_text พบ ${n} ที่ — ระบุให้ยาว/เฉพาะเจาะจงขึ้น`);
    await fs.writeFile(abs, src.replace(old_text, () => new_text), 'utf8');
    log('edit', rel(abs));
    return text(`แก้ ${rel(abs)} แล้ว`);
  }));

  server.registerTool('make_directory', {
    description: 'Create directory (including recursive parent folders)',
    inputSchema: {
      path: z.string().describe('Directory path to create'),
    },
  }, guard(async ({ path: p }) => {
    const abs = await resolveSafe(p);
    await fs.mkdir(abs, { recursive: true });
    return text(`สร้าง ${rel(abs)}/ แล้ว`);
  }));

  server.registerTool('move_path', {
    description: 'Move or rename file or directory within workspace (will not overwrite existing destination)',
    inputSchema: {
      from: z.string().describe('Source path'),
      to: z.string().describe('Destination path'),
    },
  }, guard(async ({ from, to }) => {
    const a = await resolveSafe(from, { mustExist: true });
    const b = await resolveSafe(to);
    if (a === ROOT || b === ROOT) throw new Error('path ไม่ถูกต้อง');
    if (await fs.stat(b).then(() => true, () => false)) throw new Error('ปลายทางมีอยู่แล้ว');
    await fs.mkdir(path.dirname(b), { recursive: true });
    await fs.rename(a, b);
    log('move', rel(a), '->', rel(b));
    return text(`ย้าย ${rel(a)} → ${rel(b)} แล้ว`);
  }));

  server.registerTool('delete_path', {
    description: 'Delete file or directory (directories require recursive=true). Cannot delete workspace root itself',
    inputSchema: {
      path: z.string().describe('Path to file or folder to delete'),
      recursive: z.boolean().default(false).describe('Must be true when deleting a directory'),
    },
  }, guard(async ({ path: p, recursive }) => {
    const abs = await resolveSafe(p, { mustExist: true });
    if (abs === ROOT) throw new Error('ห้ามลบโฟลเดอร์ทำงานเอง');
    const st = await fs.lstat(abs);
    if (st.isDirectory() && !recursive) throw new Error('เป็นโฟลเดอร์ ต้องตั้ง recursive=true');
    await fs.rm(abs, { recursive: st.isDirectory(), force: false });
    log('delete', rel(abs));
    return text(`ลบ ${rel(abs)} แล้ว`);
  }));
}

server.registerTool('search_text', {
  description: 'Search text (case-insensitive) across files in specified directory, skipping node_modules and .git',
  inputSchema: {
    query: z.string().min(1).describe('Text query to search'),
    path: z.string().default('.').describe('Subdirectory to search (defaults to ".")'),
    max_results: z.number().int().min(1).max(500).default(100).describe('Maximum matching lines to return'),
  },
}, guard(async ({ query, path: p, max_results }) => {
  const start = await resolveSafe(p, { mustExist: true });
  const q = query.toLowerCase();
  const hits = [];
  async function walk(dir) {
    for (const e of await fs.readdir(dir, { withFileTypes: true })) {
      if (hits.length >= max_results) return;
      const full = path.join(dir, e.name);
      if (SECRET_RE.test(full)) continue;
      if (e.isDirectory()) { if (!SKIP_DIRS.has(e.name)) await walk(full); continue; }
      const st = await fs.stat(full).catch(() => null);
      if (!st || st.size > MAX_READ_BYTES) continue;
      const buf = await fs.readFile(full).catch(() => null);
      if (!buf || buf.subarray(0, 8000).includes(0)) continue;
      buf.toString('utf8').split('\n').forEach((line, i) => {
        if (hits.length < max_results && line.toLowerCase().includes(q)) hits.push(`${rel(full)}:${i + 1}: ${line.trim().slice(0, 200)}`);
      });
    }
  }
  const st0 = await fs.stat(start);
  if (st0.isDirectory()) await walk(start); else await walk(path.dirname(start));
  return text(hits.length ? hits.join('\n') : 'ไม่พบ');
}));

// ---------- run_command & execute_command (opt-in + allowlist) ----------
if (!opts.readonly && opts.shell.length) {
  const WIN_CMD_SHIMS = new Set(['npm', 'npx', 'pnpm', 'yarn']); // บน Windows เป็น .cmd ต้องผ่าน shell
  const SAFE_ARG = /^[\w@\/.:=+\-,]+$/;                          // ใช้ตรวจ args เมื่อต้องเปิด shell

  const toolDescription = `Execute terminal / shell / CLI commands in workspace directory to install packages, run dev servers, or execute scripts. ` +
    `Allowed commands: ${opts.shell.join(', ')}. ` +
    `Examples: command="npm", args=["install"] or command="cmd", args=["/c", "dir"] or command="powershell", args=["-Command", "npm run dev"]`;

  const toolSchema = {
    command: z.string().describe('Command name, e.g. "npm", "node", "git", "python", "cmd", "powershell"'),
    args: z.union([z.array(z.string()), z.string()]).default([]).describe('Arguments as array or string, e.g. ["install"]'),
    cwd: z.string().default('.').describe('Subdirectory to execute in'),
    timeout_sec: z.number().int().min(1).max(600).default(120).describe('Timeout in seconds (default 120)'),
  };

  const commandHandler = guard(async ({ command, args, cwd, timeout_sec }) => {
    let cmd = (command || '').trim();
    let cmdArgs = Array.isArray(args)
      ? [...args]
      : (typeof args === 'string' && args.trim() ? args.trim().split(/\s+/) : []);

    // ถ้า AI ส่ง command มาเป็นสตริงยาวรวม args เช่น "npm install"
    if (cmd.includes(' ') && cmdArgs.length === 0) {
      const parts = cmd.split(/\s+/);
      cmd = parts[0];
      cmdArgs = parts.slice(1);
    }

    const name = cmd.toLowerCase().replace(/\.(exe|cmd|bat)$/, '');
    if (cmd !== path.basename(cmd)) throw new Error('ระบุเฉพาะชื่อคำสั่ง ห้ามมี path');
    if (!opts.shell.includes(name)) throw new Error(`คำสั่งนี้ไม่อยู่ในรายการที่อนุญาต: ${opts.shell.join(', ')}`);
    const dir = await resolveSafe(cwd, { mustExist: true });
    const useShell = process.platform === 'win32' && WIN_CMD_SHIMS.has(name);
    if (useShell && !cmdArgs.every((a) => SAFE_ARG.test(a))) throw new Error('args มีอักขระที่ไม่อนุญาตสำหรับคำสั่งนี้');
    log('run', cmd, cmdArgs.join(' '), 'in', rel(dir));

    return await new Promise((resolve) => {
      const child = spawn(cmd, cmdArgs, { cwd: dir, shell: useShell, windowsHide: true, env: process.env });
      let out = '';
      const add = (d) => { if (out.length < MAX_OUTPUT_CHARS * 2) out += d.toString(); };
      child.stdout.on('data', add); child.stderr.on('data', add);
      const timer = setTimeout(() => { out += '\n[timeout — ยุติโปรเซส]'; child.kill('SIGKILL'); }, timeout_sec * 1000);
      child.on('error', (e) => { clearTimeout(timer); resolve(fail(e)); });
      child.on('close', (code) => { clearTimeout(timer); resolve({ isError: code !== 0, content: [{ type: 'text', text: clip(out) + `\n[exit code ${code}]` }] }); });
    });
  });

  server.registerTool('run_command', {
    description: toolDescription,
    inputSchema: toolSchema,
  }, commandHandler);

  server.registerTool('execute_command', {
    description: toolDescription,
    inputSchema: toolSchema,
  }, commandHandler);
}

await server.connect(new StdioServerTransport());
log(`พร้อมใช้งาน root=${ROOT} readonly=${opts.readonly} shell=[${opts.readonly ? '' : opts.shell.join(',')}]`);
