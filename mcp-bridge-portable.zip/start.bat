@echo off
title MCP Control Center & Universal API Bridge
color 0B
echo ====================================================
echo    MCP Control Center & Universal API Bridge
echo ====================================================
echo.

if exist "%~dp0dist\app.js" (
    cd /d "%~dp0"
) else (
    cd /d "%~dp0\.."
)

echo [*] Starting MCP API Bridge Engine...
start "" http://localhost:3000/
node dist/app.js

if %errorlevel% neq 0 (
    echo.
    echo [!] Server stopped with exit code: %errorlevel%
    pause
)
exit
